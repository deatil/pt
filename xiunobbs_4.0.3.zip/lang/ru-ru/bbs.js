var lang = {
	'warning': 'Внимание',
	'tips_title': 'Подсказка: ', 
	'confirm': 'Подтвердить',
	'confirm_title': 'Подтверждение',
	'close': 'Закрыть',
	'yes': 'Да',
	'no': 'Нет',
	'open': 'Открыть',
	'close': 'Закрыть',
	
	'please_choose_thread':'Выберите тему',
	'move_forum':'Переместить форум',
	'choose_move_forum':'Выберите целевой форум',
	'top_0':'Отменить закрепление',
	'top_1':'Поднять на форуме',
	'top_3':'Поднять на сайте',
	'top_thread':'Поднять тему',
	'top_range':'Top range',
	'confirm_delete_thread':'Вы точно ходите удалить выбранные темы: {n} ?',
	'confirm_delete':'Вы уверены ?',
	'close_thread':'Закрытие темы',
	'close_status':'Статус',
	
	// hook lang_en_us_bbs_js.htm
	
};
