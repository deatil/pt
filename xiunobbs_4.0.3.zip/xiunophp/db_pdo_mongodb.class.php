<?php

class db_pdo_mongodb {
	
}


?>