<?php

/*
	Xiuno BBS 4.0 主题高亮
*/

!defined('DEBUG') AND exit('Forbidden');


?>